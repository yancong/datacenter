class MyHandler extends Paged.Handler {
    constructor(chunker, polisher, caller) {
        super(chunker, polisher, caller);
    }

    beforeParsed(content) {
        // console.log(content);
  
    }
}
Paged.registerHandlers(MyHandler);